// =============================================
// 카카오톡 자동화 설정 파일
// 이 파일에서 검색 키워드, 메시지, 이미지를 설정하세요.
// =============================================

const config = {
  // 반복할 채팅방 목록
  // 각 항목: { keyword: '검색 키워드', message: '보낼 메시지', imagePath: '이미지 경로 (없으면 null)' }
  targets: [
    {
      keyword: '팀 공지',           // 채팅방 검색 키워드
      message: '안녕하세요! 공지사항입니다.',  // 전송할 메시지
      imagePath: './images/notice.png'  // 전송할 이미지 경로 (없으면 null)
    },
    {
      keyword: '개발팀',
      message: '개발팀 공지입니다.',
      imagePath: './images/dev.png'
    },
    // 필요에 따라 항목 추가
  ],

  // 타이밍 설정 (ms 단위)
  delay: {
    appLaunch: 3000,       // 앱 실행 후 대기 시간 (3초)
    afterShortcut: 800,    // 단축키 입력 후 대기 시간
    afterSearch: 1500,     // 검색 후 결과 로딩 대기 시간
    afterOpenChat: 1000,   // 채팅방 열린 후 대기 시간
    afterMessage: 500,     // 메시지 입력 후 대기 시간
    afterImageAttach: 2000,// 이미지 첨부 후 대기 시간
    afterSend: 1000,       // 전송 후 대기 시간
    betweenTargets: 1500,  // 각 채팅방 처리 사이 대기 시간
  }
};

module.exports = config;
