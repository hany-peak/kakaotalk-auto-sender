const { keyboard, mouse, screen, straightTo, centerOf, Key, Button, sleep } = require('@nut-tree/nut-js');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const config = require('./config');

// nut-js 설정
keyboard.config.autoDelayMs = 50;
mouse.config.autoDelayMs = 50;
mouse.config.mouseSpeed = 1000;

// =============================================
// 유틸리티 함수
// =============================================

/**
 * 지정된 시간(ms)만큼 대기
 */
const wait = (ms) => sleep(ms);

/**
 * macOS 터미널 명령 실행
 */
const runCommand = (cmd) => {
  return new Promise((resolve, reject) => {
    exec(cmd, (error, stdout, stderr) => {
      if (error) reject(error);
      else resolve(stdout);
    });
  });
};

/**
 * 카카오톡 앱 실행
 */
const launchKakaoTalk = async () => {
  console.log('📱 카카오톡 실행 중...');
  await runCommand('open -a KakaoTalk');
  await wait(config.delay.appLaunch);
  // 카카오톡 창을 맨 앞으로 가져오기
  await runCommand(`osascript -e 'tell application "KakaoTalk" to activate'`);
  await wait(1000);
  console.log('✅ 카카오톡 실행 완료');
};

/**
 * Command + 2 로 채팅 목록 열기
 */
const openChatList = async () => {
  console.log('💬 채팅 목록 열기 (Cmd+2)...');
  await keyboard.pressKey(Key.LeftSuper, Key.Digit2);
  await keyboard.releaseKey(Key.LeftSuper, Key.Digit2);
  await wait(config.delay.afterShortcut);
  console.log('✅ 채팅 목록 열기 완료');
};

/**
 * 채팅방 검색 (Cmd+F 또는 검색창 클릭)
 */
const searchChatRoom = async (keyword) => {
  console.log(`🔍 "${keyword}" 검색 중...`);

  // Cmd+F 로 검색창 열기
  await keyboard.pressKey(Key.LeftSuper, Key.F);
  await keyboard.releaseKey(Key.LeftSuper, Key.F);
  await wait(config.delay.afterShortcut);

  // 기존 검색어 모두 지우기
  await keyboard.pressKey(Key.LeftSuper, Key.A);
  await keyboard.releaseKey(Key.LeftSuper, Key.A);
  await keyboard.pressKey(Key.Delete);
  await keyboard.releaseKey(Key.Delete);
  await wait(200);

  // 키워드 입력
  await keyboard.type(keyword);
  await wait(config.delay.afterSearch);

  console.log(`✅ "${keyword}" 검색 완료`);
};

/**
 * 검색 결과 첫 번째 채팅방 열기 (Enter 또는 방향키+Enter)
 */
const openFirstSearchResult = async () => {
  console.log('📂 첫 번째 검색 결과 채팅방 열기...');

  // 방향키 아래로 첫 번째 결과 선택
  await keyboard.pressKey(Key.Down);
  await keyboard.releaseKey(Key.Down);
  await wait(300);

  // Enter 로 채팅방 열기
  await keyboard.pressKey(Key.Return);
  await keyboard.releaseKey(Key.Return);
  await wait(config.delay.afterOpenChat);

  console.log('✅ 채팅방 열기 완료');
};

/**
 * 메시지 입력 및 전송
 */
const sendMessage = async (message) => {
  console.log(`✉️  메시지 입력 중: "${message}"`);

  // 입력창 포커스 (Cmd+T 는 새 탭이므로 클릭 대신 바로 타이핑)
  await keyboard.type(message);
  await wait(config.delay.afterMessage);

  console.log('✅ 메시지 입력 완료');
};

/**
 * 이미지 첨부 (Cmd+Shift+T 또는 클립보드 붙여넣기 방식)
 */
const attachImage = async (imagePath) => {
  if (!imagePath) return;

  const absolutePath = path.resolve(imagePath);

  if (!fs.existsSync(absolutePath)) {
    console.warn(`⚠️  이미지 파일을 찾을 수 없습니다: ${absolutePath}`);
    return;
  }

  console.log(`🖼️  이미지 첨부 중: ${absolutePath}`);

  // AppleScript로 이미지를 클립보드에 복사 후 붙여넣기
  await runCommand(
    `osascript -e 'set the clipboard to (read (POSIX file "${absolutePath}") as JPEG picture)'`
  );
  await wait(500);

  // Cmd+V 로 붙여넣기
  await keyboard.pressKey(Key.LeftSuper, Key.V);
  await keyboard.releaseKey(Key.LeftSuper, Key.V);
  await wait(config.delay.afterImageAttach);

  console.log('✅ 이미지 첨부 완료');
};

/**
 * 메시지+이미지 한꺼번에 전송 (Enter)
 */
const sendAll = async () => {
  console.log('🚀 전송 중...');
  await keyboard.pressKey(Key.Return);
  await keyboard.releaseKey(Key.Return);
  await wait(config.delay.afterSend);
  console.log('✅ 전송 완료');
};

/**
 * 채팅방 닫기 (Cmd+W)
 */
const closeChatRoom = async () => {
  console.log('❌ 채팅방 닫기...');
  await keyboard.pressKey(Key.LeftSuper, Key.W);
  await keyboard.releaseKey(Key.LeftSuper, Key.W);
  await wait(500);
  console.log('✅ 채팅방 닫기 완료');
};

// =============================================
// 메인 실행 함수
// =============================================

const main = async () => {
  console.log('==============================');
  console.log('  카카오톡 자동화 시작');
  console.log('==============================');
  console.log(`총 ${config.targets.length}개 채팅방 처리 예정\n`);

  try {
    // 1. 카카오톡 실행
    await launchKakaoTalk();

    // 2. 채팅 목록 열기 (Cmd+2)
    await openChatList();

    // 3~5. 각 타겟 채팅방 순서대로 처리
    for (let i = 0; i < config.targets.length; i++) {
      const target = config.targets[i];
      console.log(`\n----- [${i + 1}/${config.targets.length}] "${target.keyword}" 처리 시작 -----`);

      // 3. 키워드 검색 후 첫 번째 채팅방 열기
      await searchChatRoom(target.keyword);
      await openFirstSearchResult();

      // 4. 메시지 입력
      await sendMessage(target.message);

      // 4. 이미지 첨부 (있는 경우)
      if (target.imagePath) {
        await attachImage(target.imagePath);
      }

      // 4. 전송
      await sendAll();

      // 5. 채팅방 닫기
      await closeChatRoom();

      // 다음 채팅방 처리 전 대기
      if (i < config.targets.length - 1) {
        await wait(config.delay.betweenTargets);
      }

      console.log(`✅ [${i + 1}/${config.targets.length}] "${target.keyword}" 처리 완료`);
    }

    console.log('\n==============================');
    console.log('  모든 작업 완료! 🎉');
    console.log('==============================');

  } catch (error) {
    console.error('\n❌ 오류 발생:', error.message);
    console.error(error.stack);
    process.exit(1);
  }
};

// 스크립트 실행
main();
